package com.example.databasefirebase;

import static org.junit.Assert.*;

/**
 * Created by Burhan Infinity on 12/1/2017.
 */
public class logInActivityTest {



}